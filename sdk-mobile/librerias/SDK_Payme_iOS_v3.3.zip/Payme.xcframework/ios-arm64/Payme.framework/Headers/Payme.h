//
//  Payme.h
//  Payme
//
//  Created by Levis Silvestre on 30/07/24.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

//! Project version number for Payme.
FOUNDATION_EXPORT double PaymeVersionNumber;

//! Project version string for Payme.
FOUNDATION_EXPORT const unsigned char PaymeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Payme/PublicHeader.h>


